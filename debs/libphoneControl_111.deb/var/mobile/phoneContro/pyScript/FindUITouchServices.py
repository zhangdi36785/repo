import time
from threading import Thread
from phonecontrol.client import phoneControl


class TouchFind:
    def __init__(self, phone):
        """

        :type phone: object
        """
        super().__init__()
        self._phone = phone

    def FindButtonAndTouch(self, bid, uiName, UiPointX=-1, UiPointY=-1, findUiText=''):
        canTap = False

        result = self._phone.FindUI(bid, uiName)
        if result is None:
            return canTap
        uiCount = result["count"]
        if uiCount < 0:
            return canTap

        uiArray = result['info']
        print(uiArray)
        for item in uiArray:
            touch = item['touch']
            x = item['x']
            y = item['y']
            text = item['text']
            if findUiText == text:
                result = self._phone.TapUI(bid, touch)
                canTap = result
                break
            if x == UiPointX and y == UiPointY:
                result = self._phone.TapUI(bid, touch)
                canTap = result
                break

        return canTap

    def FindUiWithPoint(self, bid, uiName, UiPointX=0, UiPointY=0):
        bid = bid
        canTap = False

        result = self._phone.FindUI(bid, uiName)
        uiCount = result["count"]
        if uiCount < 0:
            return canTap

        uiArray = result['info']

        for item in uiArray:
            x = item['x']
            y = item['y']
            if x == UiPointX and y == UiPointY:
                canTap = True
                break
        return canTap

    def FindUi(self, bid, uiName, findUiText):
        bid = bid
        canTap = False

        result = self._phone.FindUI(bid, uiName)
        uiCount = result["count"]
        if uiCount < 0:
            return canTap

        uiArray = result['info']

        for item in uiArray:
            text = item['text']
            if text == findUiText:
                canTap = True
                break

        return canTap

    def FindAndTouch(self, bid, uiName, findUiText, offsetX=0, offsetY=0):
        """

        :param offsetY:
        :param offsetX:
        :param bid:
        :param uiName: ''
        :param findUiText:
        :return:
        """
        bid = bid
        canTap = False

        result = self._phone.FindUI(bid, uiName)
        if result is None:
            return canTap
        uiCount = result["count"]
        if uiCount < 0:
            return canTap

        uiArray = result['info']

        for item in uiArray:
            text = item['text']
            if text == findUiText or findUiText == '*':
                self._phone.TouchTap(item['x'] + offsetX, item['y'] + offsetY)
                canTap = True
                break

        return canTap

    def FindUiInfo(self, bid, uiName, findUiText):
        """

        :param offsetY:
        :param offsetX:
        :param bid:
        :param uiName: ''
        :param findUiText:
        :return:
        """
        bid = bid
        x = 0
        y = 0
        touch = 0

        result = self._phone.FindUI(bid, uiName)
        if result is None:
            return x, y, touch
        uiCount = result["count"]
        if uiCount < 0:
            return x, y, touch

        uiArray = result['info']

        for item in uiArray:
            text = item['text']
            if text == findUiText or findUiText == '*':
                x = item['x']
                y = item['y']
                touch = item['touch']
                break

        return x, y, touch
