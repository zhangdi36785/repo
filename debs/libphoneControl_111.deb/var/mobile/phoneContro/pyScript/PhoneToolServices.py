from phonecontrol.client import phoneControl
import time
import plistlib
import random


class PhoneToolServices:
	def __init__(self, phone: 'phonecontrol.client'):
		self._phone = phone
	
	# @staticmethod
	# @property
	def getConfigDict(self):
		fileName = "/var/mobile/FFFaker/config.plist"
		config = None
		with open(fileName, 'rb') as fp:
			config = plistlib.load(fp)
			print(config)
		
		return config
	
	def randomDeviceType(self):
		self._phone.ToastMessage('随机新设备类型')
		
		fileName = "/var/mobile/FFFaker/config.plist"
		config = self.getConfigDict()
		
		if config is None:
			return
		
		phoneDict = {"iPhone11,2": "D321AP",
		             "iPhone11,4": "D331AP",
		             "iPhone12,1": "N104AP",
		             "iPhone12,3": "D421AP",
		             "iPhone12,5": "D431AP",
		             "iPhone12,8": "D79AP",
		             "iPhone13,1": "D52gAP",
		             "iPhone13,2": "D53gAP",
		             "iPhone13,3": "D53pAP",
		             "iPhone13,4": "D54pAP",
		             }
		
		r2 = random.randint(0, phoneDict.__len__())
		if r2 == 0:
			return
		
		deviceType, deviceModel = random.choice(list(phoneDict.items()))
		
		config['IsDeviceFake'] = True
		config['DeviceFakeType'] = deviceType
		config['DeviceModelType'] = deviceModel
		
		with open(fileName, 'wb') as fp:
			plistlib.dump(config, fp)
	
	def newDevice(self, bidName=None, NeedNewType=False):
		"""
		新设备，清理沙盒等
		:param bidName:清理Bid
		:param NeedNewType:
		:return:
		"""
		for i in range(0, 100):
			result = self._phone.NewApp(bidName)
			
			if result is None:
				time.sleep(3)
				continue
			else:
				ret = result['result']
				if ret is True and NeedNewType is True:
					self.randomDeviceType()
					
					break
				elif ret is True:
					break
				elif ret is False:
					self._phone.ToastMessage('新机失败')
					time.sleep(3)
					continue
	
	def reloadVpn(self):
		"""关闭重启VPN"""
		self._phone.CloseVpn()
		time.sleep(2)
		self._phone.OpenVpn()
		time.sleep(3)
	
	def checkLockAndLaunchApp(self, bid):
		ret = self.checkAndLockScreen()
		if ret is False:
			return ret
		ret = self.launchApp(bid)
		return ret
	
	def checkAndLockScreen(self):
		"""
		检查并解锁屏幕
		:return:
		"""
		result = self._phone.ScreenState()
		if result is None:
			return False
		state = result['lock']
		if state is True:
			self._phone.Home()
			self._phone.Home()
			return True
		else:
			return True
	
	def launchApp(self, bid):
		"""
		启动一个App到前台
		:param bid:
		:return:
		"""
		self._phone.ToastMessage('Get AppFrontMost ', 1)
		frontBid = self._phone.AppFrontMost()
		
		if frontBid == bid:
			return True
		
		self._phone.OpenApp(bid)
		
		frontBid = self._phone.AppFrontMost()
		time.sleep(2)
		
		self._phone.ToastMessage('AppBid:{0}'.format(frontBid), 1)
		
		if frontBid == bid:
			return True
		
		return False
