import requests


class LogServices:
    def __init__(self, deviceId, url='http://192.168.3.66:88/api/phone/log'):
        super().__init__()
        self._url = url
        self._timeout = 10
        self._deviceId = deviceId

    def RemoteLogInfo(self, content, level='info'):
        data = {'deviceId': self._deviceId, 'content': content, 'level': level}
        result = requests.post(self._url, data=data, timeout=self._timeout)
        return result

    def RemoteLogWarn(self, content, level='warn'):
        data = {'deviceId': self._deviceId, 'content': content, 'level': level}
        result = requests.post(self._url, data=data, timeout=self._timeout)
        return result

    def RemoteLogDebug(self, content, level='debug'):
        data = {'deviceId': self._deviceId, 'content': content, 'level': level}
        result = requests.post(self._url, data=data, timeout=self._timeout)
        return result

    def RemoteLogError(self, content, level='error'):
        data = {'deviceId': self._deviceId, 'content': content, 'level': level}
        result = requests.post(self._url, data=data, timeout=self._timeout)
        return result
