import time
from threading import Thread
from phonecontrol.client import phoneControl


class ToastMsg(Thread):
    def __init__(self, phone):
        super().__init__()
        self._msg = ''
        self._type = 1
        self._run = True
        self._phone = phone

    def run(self):
        while self._run:
            if self._msg == '':
                continue
            self._phone.ToastMessage(self._msg, self._type)
            time.sleep(1)
        self._phone.ToastMessage(self._msg, self._type)

    def Stop(self):
        self._run = False

    def ChangeMsg(self, message, msgType=4):
        self._msg = message
        self._type = msgType
        self._phone.ToastMessage(self._msg, self._type)
