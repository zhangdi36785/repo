TASK_DeviceInfo = 1
TASK_AppFrontMost = 5
TASK_AppForeground = 6
TASK_AppClose = 112

TASK_Toast = 7
TASK_ScreenState = 11
TASK_TouchDown = 101
TASK_TouchMove = 102
TASK_TouchUp = 103
TASK_TouchTap = 105
TASK_TouchTapMove = 108
TASK_Home = 106
TASK_KeyBoard = 111
TASK_TaskScreen = 107

Task_GetAllBackUp = 201
Task_GetAppBackUp = 202
Task_GetAppBackUpNext = 203
Task_GetAppInstallInfo = 205
Task_GetFileData = 301
Task_WriteFileData = 302
Task_GetNetWorkIpInfo = 501
Task_GetScreenOrc = 601
TASK_VPN = 902
TASK_InstallApp = 1002
TASK_UnInstallApp = 1003
TASK_BackUpApp = 1005
TASK_RestoreApp = 1006
TASK_NewApp = 1007

TASK_FindUI = 2001
TASK_FindTapUI = 2002
TASK_FindClassRunMethods = 2003

