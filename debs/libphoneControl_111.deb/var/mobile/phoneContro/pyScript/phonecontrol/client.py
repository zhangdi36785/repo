import requests
import json

from phonecontrol import taskType


def GetApiCommand(opCode, data):
	d = {'opCode': opCode, "paraData": data}
	return json.dumps(d)


class phoneControl:
	
	def __init__(self, url='http://127.0.0.1'):
		super().__init__()
		self._spUrl = url + ':52717/api'
		self._doUrl = url + ':52718/api'
		self.timeout = 30
		self._tmpTimeout = self.timeout
		self.isProxy = False
		self._getDeviceInfo()
		self.printMsg = True
	
	def _getDeviceInfo(self):
		result = self.DeviceInfo()
		
		if result is None or 'deviceId' not in result:
			self.deviceId = ''
			return
		
		deviceId = result['deviceId']
		self.deviceId = deviceId
	
	def _ex(self, message):
		raise Exception(message)
	
	def _responseData(self, response):
		if response.status_code != 200:
			self._ex('Can not connect Server')
		res = json.loads(response.content)
		
		Ret = res['Ret']
		if Ret != 0:
			self._ex(res['Msg'])
		return res['Data']
	
	def _postSpData(self, data):
		try:
			head = {'Content-Type': 'application/json'}
			proxies = {}
			if self.isProxy is True:
				proxies = {'http': 'http://127.0.0.1:8888/'};
			
			response = requests.post(self._spUrl, data=data, timeout=self.timeout, proxies=proxies, headers=head)
			return self._responseData(response)
		except Exception as e:
			print(e)
	
	def _postDoData(self, data):
		try:
			response = requests.post(self._doUrl, data=data, timeout=self.timeout)
			return self._responseData(response)
		except Exception as e:
			print(e)
	
	def TouchTap(self, x, y):
		d = GetApiCommand(taskType.TASK_TouchTap, {'x': x, 'y': y})
		result = self._postSpData(d)
		return result
	
	def OpenVpn(self):
		d = GetApiCommand(taskType.TASK_VPN, {'type': 0})
		result = self._postSpData(d)
		return result
	
	def CloseVpn(self):
		d = GetApiCommand(taskType.TASK_VPN, {'type': 1})
		result = self._postSpData(d)
		return result
	
	def TouchMoveTap(self, x, y, dx, dy):
		d = GetApiCommand(taskType.TASK_TouchTapMove, {'x': x, 'y': y, 'dx': dx, 'dy': dy})
		result = self._postSpData(d)
		return result
	
	def Home(self):
		d = GetApiCommand(taskType.TASK_Home, {})
		result = self._postSpData(d)
		return result
	
	def DeviceInfo(self):
		d = GetApiCommand(taskType.TASK_DeviceInfo, {})
		result = self._postSpData(d)
		return result
	
	def TaskScreen(self):
		d = GetApiCommand(taskType.TASK_TaskScreen, {})
		result = self._postSpData(d)
		return result
	
	def AppFrontMost(self):
		"""
		返回一个前台正在运行的App
		:return:bid 或者 为空
		"""
		d = GetApiCommand(taskType.TASK_AppFrontMost, {})
		result = self._postSpData(d)
		return result
	
	def ToastMessage(self, message, messageType=4):
		if self.printMsg is False:
			return
		d = GetApiCommand(taskType.TASK_Toast, {'toastMessage': message, 'toastType': messageType})
		return self._postSpData(d)
	
	def BackUpApp(self, bid):
		d = GetApiCommand(taskType.TASK_BackUpApp, {'bid': bid})
		return self._postSpData(d)
	
	def ScreenState(self):
		d = GetApiCommand(taskType.TASK_ScreenState, {})
		return self._postSpData(d)
	
	def AppInstallInfo(self, bid):
		d = GetApiCommand(taskType.Task_GetAppInstallInfo, {'bid': bid})
		return self._postSpData(d)
	
	def _backUpTimeOut(self, timeOut=30):
		self._tmpTimeout = self.timeout
		self.timeout = timeOut
	
	def _restoreTimeOut(self):
		self.timeout = self._tmpTimeout
	
	def NetWorkIpInfo(self, url="https://lumtest.com/myip.json"):
		self._backUpTimeOut()
		d = GetApiCommand(taskType.Task_GetNetWorkIpInfo, {'url': url})
		ret = self._postSpData(d)
		self._restoreTimeOut()
		return ret
	
	def NewApp(self, bid):
		"""
		创建新虚拟app环境
		:param bid:
		:return:
		"""
		d = GetApiCommand(taskType.TASK_NewApp, {'bid': bid})
		return self._postSpData(d)
	
	def RestoreApp(self, bid, version):
		d = GetApiCommand(taskType.TASK_RestoreApp, {'bid': bid, 'version': version})
		return self._postSpData(d)
	
	def RunMethods(self, bid, className, methodName):
		d = GetApiCommand(taskType.TASK_FindClassRunMethods,
		                  {'bid': bid, 'className': className, 'methodName': methodName})
		return self._postSpData(d)
	
	def FindUI(self, bid, name, tag=0):
		"""
		寻找一个UI并且返回数据
		:param bid:
		:param name:
		:param tag:
		:return:
		"""
		
		tmpTimeOut = self.timeout
		self.timeout = 0.2
		d = GetApiCommand(taskType.TASK_FindUI, {'bid': bid, 'name': name, 'tag': tag})
		
		result = self._postSpData(d)
		self.timeout = tmpTimeOut
		return result
	
	def TapUI(self, bid, touch, name="UIButton"):
		"""
		点击一个寻找到的UI
		:param bid:
		:param name:
		:param tag:
		:return:
		"""
		d = GetApiCommand(taskType.TASK_FindTapUI, {'bid': bid, 'name': name, 'touch': touch, 'tag': 0})
		return self._postSpData(d)
	
	def GetAllBackUpInfo(self, bid=''):
		"""
		获取所有备份，bid有值时候。为对应app备份
		:param bid:
		:return:
		"""
		d = GetApiCommand(taskType.Task_GetAllBackUp, {'bid': bid})
		return self._postSpData(d)
	
	def GetAppBackUpInfo(self, bid):
		d = GetApiCommand(taskType.Task_GetAppBackUp, {'bid': bid})
		return self._postSpData(d)
	
	def GetAppBackUpNext(self, bid):
		"""
		获取下一个备份
		:param bid:
		:return:
		"""
		d = GetApiCommand(taskType.Task_GetAppBackUpNext, {'bid': bid})
		return self._postSpData(d)
	
	def InstallApp(self, path):
		tmpTimeOut = self.timeout
		self.timeout = 60
		d = GetApiCommand(taskType.TASK_InstallApp, {'path': path})
		result = self._postSpData(d)
		self.timeout = tmpTimeOut
		return result
	
	def GetScreenORC(self, x, y, width, height, isDebug=0):
		"""
		识别屏幕返回数据
		:param path:
		:param subType:
		:return:
		"""
		d = GetApiCommand(taskType.Task_GetScreenOrc,
		                  {'x': x, 'y': y, 'width': width, 'height': height, 'isDebug': isDebug})
		result = self._postSpData(d)
		return result
	
	def WriteLog(self, path, text, subType=1):
		"""
		写入日志
		:param text:
		:param path:
		:param subType:
		:return:
		"""
		d = GetApiCommand(taskType.Task_WriteFileData, {'path': path, 'text': text, 'type': subType})
		result = self._postSpData(d)
		return result
	
	def GetFileDataBase64(self, path, subType=1):
		"""
		获取一个文件的base64
		:param path:
		:param subType:
		:return:
		"""
		d = GetApiCommand(taskType.Task_GetFileData, {'path': path, 'type': subType})
		result = self._postSpData(d)
		return result
	
	def GetFileData(self, path, subType=2):
		"""
		获取一个文件的Text内容
		:param path:
		:param subType:
		:return:
		"""
		d = GetApiCommand(taskType.Task_GetFileData, {'path': path, 'type': subType})
		result = self._postSpData(d)
		return result
	
	def RemoveFileData(self, path, subType=3):
		"""
		删除一个文件
		:param path:
		:param subType:
		:return:
		"""
		d = GetApiCommand(taskType.Task_GetFileData, {'path': path, 'type': subType})
		result = self._postSpData(d)
		return result
	
	def UnInstallApp(self, bid):
		d = GetApiCommand(taskType.TASK_UnInstallApp, {'bid': bid})
		return self._postSpData(d)
	
	def KeyBoardText(self, text):
		d = GetApiCommand(taskType.TASK_KeyBoard, {'titleText': text, 'subCode': 1})
		return self._postSpData(d)
	
	def KeyBoardClear(self):
		d = GetApiCommand(taskType.TASK_KeyBoard, {'titleText': '', 'subCode': 3})
		return self._postSpData(d)
	
	def KeyBoardClearAll(self):
		d = GetApiCommand(taskType.TASK_KeyBoard, {'titleText': '', 'subCode': 2})
		return self._postSpData(d)
	
	def OpenApp(self, appIdentifier):
		"""
		运行一个App
		:param appIdentifier:App 唯一识别
		:return:
		"""
		d = GetApiCommand(taskType.TASK_AppForeground, {'appIdentifier': appIdentifier})
		return self._postSpData(d)
	
	def CloseApp(self, appIdentifier):
		"""
		运行一个App
		:param appIdentifier:App 唯一识别
		:return:
		"""
		d = GetApiCommand(taskType.TASK_AppClose, {'appIdentifier': appIdentifier})
		return self._postSpData(d)
