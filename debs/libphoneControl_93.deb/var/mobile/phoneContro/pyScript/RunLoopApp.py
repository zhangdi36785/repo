import time
from threading import Thread
from phonecontrol.client import phoneControl

bid = 'com.burbn.instagram'


def launchApp(phone):
    phone.ToastMessage('获取前台App ', 1)
    frontBid = phone.AppFrontMost()

    if frontBid != bid:
        phone.ToastMessage('Null App is Run ')
        phone.ToastMessage('打开App ')
        phone.OpenApp(bid)
        time.sleep(5)
        phone.ToastMessage('获取前台App ', 1)
        frontBid = phone.AppFrontMost()
        time.sleep(3)
        phone.ToastMessage('前台程序:{0}'.format(frontBid), 1)
    else:
        phone.ToastMessage("程序已经运行")


if __name__ == '__main__':
    phone = phoneControl()
    launchApp(phone)
    time.sleep(60)
    phone.ToastMessage("等待时间完成,退出App")
    time.sleep(1)
    phone.CloseApp(bid)
