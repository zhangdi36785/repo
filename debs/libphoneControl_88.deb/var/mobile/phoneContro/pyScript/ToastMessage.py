import time
from threading import Thread
from phonecontrol.client import phoneControl

if __name__ == '__main__':
    phone = phoneControl()
    phone.ToastMessage("提示文字1", 1)
    time.sleep(1)
    phone.ToastMessage("提示文字2", 2)
    time.sleep(1)
    phone.ToastMessage("提示文字3", 3)
    time.sleep(1)
    phone.ToastMessage("提示文字4", 4)
    time.sleep(1)
    # msg = ToastMsg(phone)
